#!/bin/bash

# === Ayuda ===
if [[ "$1" == "-help" || "$1" == "--help" ]]; then
    echo "Uso: $0 <directorio_origen> <directorio_destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 0
fi

# === Argumentos ===
ORIGEN="$1"
DESTINO="$2"

if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
    echo "Error: Debe especificar origen y destino."
    echo "Use --help para más información"
    exit 1
fi

# === Validación de existencia ===
if [ ! -d "$ORIGEN" ]; then
    echo "Error: Directorio de origen no encontrado: $ORIGEN"
    exit 2
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: Directorio de destino no encontrado: $DESTINO"
    exit 3
fi

# === Nombre del backup ===
FECHA=$(date +%Y%m%d)
NOMBRE_ORIGEN=$(basename "$ORIGEN")
ARCHIVO="$DESTINO/${NOMBRE_ORIGEN}_bkp_${FECHA}.tar.gz"

# === Ejecución del backup ===
tar -czf "$ARCHIVO" "$ORIGEN"

# === Resultado ===
if [ $? -eq 0 ]; then
    echo "Backup exitoso: $ARCHIVO"
else
    echo "Error: Fallo la creación del backup"
    exit 4
fi
